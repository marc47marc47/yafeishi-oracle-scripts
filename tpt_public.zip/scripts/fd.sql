from dual
.
prompt .....from dual
