SELECT * FROM TABLE(exasnap.display_sid('&2', &1));
