prompt alter session set events '10053 trace name context off';;

alter session set events '10053 trace name context off';
