set termout off
@"&_tpt_tempdir/set_&_tpt_tempfile..sql"
set termout on
