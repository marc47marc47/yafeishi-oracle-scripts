alter session set events '&1 trace name context off';
