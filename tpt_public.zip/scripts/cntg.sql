select &2 , count(*) from &1 group by &2 order by 2 desc;
