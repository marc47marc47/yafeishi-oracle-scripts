prompt alter session set events 'immediate trace name &1 level &2';;
alter session set events 'immediate trace name &1 level &2';
