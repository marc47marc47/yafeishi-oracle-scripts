#!/bin/env perl
#
# $Header: oss/image/SupportTools/exachk/show_fil_in_html.pl rojuyal_exachk_12/2 2014/03/31 23:22:11 rojuyal Exp $
#
# show_fil_in_html.pl 
#
# Copyright (c) 2013, 2014, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      show_fil_in_html.pl	- Append small html files into main html report. 
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    rojuyal     04/04/14 	- Creation


use strict;
use warnings;

use Getopt::Long;

my ($SOURCEFILE);
my ($SFH_RCNT);
my ($SFH_HOSTS);
my ($WH_HOSTS);
my ($CID_HTML_REPFILE);
my ($SFH_ID);
my ($SFH_SUFFIX);
my ($G_OUT_LINES)	= 20;
my ($WOH_LINE_CNT);

sub usage {
    print "Usage: $0 -f SOURCEFILE -o CID_HTML_REPFILE -c SFH_CNT -i SFH_ID -x SFH_SUFFIX -h SFH_HOSTS -w WH_HOSTS -l G_OUT_LINES -n WOH_LINE_CNT\n"; 
    exit;
}

GetOptions(
    "f=s" => \$SOURCEFILE,
    "o=s" => \$CID_HTML_REPFILE,
    "c=n" => \$SFH_RCNT,
    "i=s" => \$SFH_ID,
    "x=s" => \$SFH_SUFFIX,
    "h=s" => \$SFH_HOSTS,
    "w=s" => \$WH_HOSTS,
    "l=n" => \$G_OUT_LINES,
    "n=n" => \$WOH_LINE_CNT,
) or usage();

my ($SFH_DINDEX) 	= 0;
my ($SFH_INDEX) 	= 0;
my ($SFH_SHOW_LINE)	= 1;
my ($SFH_DISPLAY_MORE)	= 0;

open( my $FH, "<", "$SOURCEFILE" ) or die "Cannot open $SOURCEFILE: $!";
open( my $CHR, ">>", "$CID_HTML_REPFILE" ) or die "Cannot open $CID_HTML_REPFILE: $!";
while(my $sfh_line = <$FH>) {
	my ($sfh_lined)	=	$sfh_line;
	$sfh_lined =~ s/TO REVIEW COLLECTED //;
	$sfh_lined =~ s/>/\&gt;/g;
	$sfh_lined =~ s/</\&lt;/g;

	my ($SFH_MNAME);
	my ($INST_NAME);

	if ( $SFH_RCNT > 1 && $sfh_line =~ m/TO REVIEW COLLECTED DATA/i ) {
	    if ( $sfh_line =~ m/ DATABASE -/i or $sfh_line =~ m/ ORACLE_HOME -/i ) {
		$SFH_MNAME	= (split ' ', $sfh_line)[7];	
	    }
	    else {
		$SFH_MNAME	= (split ' ', $sfh_line)[5];
	    }	
	
	    if ( $SFH_HOSTS =~ m/$SFH_MNAME/i ) {
		$SFH_SHOW_LINE	= 1;
	    }
	    else {
		$SFH_SHOW_LINE	= 0;
	    }


	    if ( $sfh_line =~ m/ DATABASE_HOME -/i or $sfh_line =~ m/DATABASE_HOME - TIMESTEN/i ) {
		$SFH_MNAME      = (split ' ', $sfh_line)[7];
		if ( $sfh_line =~ m/BI_INSTANCE -/i ) {
		    if ( $WH_HOSTS =~ m/$SFH_MNAME:/i ) {
  		    	$INST_NAME	= (split ' ', $sfh_line)[10];    
			if ( $WH_HOSTS =~ m/$INST_NAME/i ) {
			    $SFH_SHOW_LINE  = 1;
			}
			else {
			    $SFH_SHOW_LINE  = 0;
			}
                    }
		    else {
			$SFH_SHOW_LINE = 0;	
		    }
		}
		else {
		    if ( $WH_HOSTS =~ m/$SFH_MNAME$/i ) {
			$SFH_SHOW_LINE  = 1;
		    }
		    else {
			$SFH_SHOW_LINE  = 0;
		    }
		}
	    }
	}

	if ( $SFH_SHOW_LINE == 1 ) {
	    if ( $SFH_DINDEX == $G_OUT_LINES ) {
		print $CHR "<div id=$SFH_ID" . '_more_text' . $SFH_SUFFIX . ' style="DISPLAY: none">' . "\n";

	    	$SFH_DISPLAY_MORE = 1;
	    }
      	    print $CHR $sfh_lined."\n";
	
	    $SFH_DINDEX++;
	}
	$SFH_INDEX++;

	if ( $SFH_INDEX >= $WOH_LINE_CNT && $SFH_DINDEX > $G_OUT_LINES && $SFH_DISPLAY_MORE == 1 ) {
	    print $CHR qq{</div><a id="$SFH_ID} . qq{_more_text$SFH_SUFFIX} . qq{_mh" class=more_less_style onclick="javascript:ShowHide('} . qq{$SFH_ID} . qq{_more_text$SFH_SUFFIX')" href="javascript:;">Click for more data</a>\n};
	}

}
close($CHR);
close($FH);
