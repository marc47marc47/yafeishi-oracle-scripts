#!/bin/bash
#
# $Header: tfa/src/orachk/src/checkDiskScheduler.sh cgirdhar_issues_2105-02-19/1 2015/02/19 16:07:11 cgirdhar Exp $
#
# checkDiskScheduler.sh
#
# Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      checkDiskScheduler.sh - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    cgirdhar    02/10/15 - Checking ASM disks I/O scheduler setting
#    cgirdhar    02/10/15 - Creation
#

# functions

function check_kernel_for_elevator {

if [ -r /boot/config-`uname -am | awk '{print $3}'` ]
 then
  v_def_kern_iosched=$(cat /boot/config-`uname -am | awk '{print $3}'`| grep CONFIG_DEFAULT_IOSCHED | awk -F= '{print $2}' | sed 's/.*\"\([^]]*\)\".*/\1/')

  if [ "${v_def_kern_iosched}" = "deadline" ]
   then
    report_command=$(echo "$report_command\nKernel default IO scheduler is deadline.")
    status=0
  else
    status=1
  fi
else
 report_command=$(echo "$report_command\nUnable to read kernel config file.")
 status=1
fi

}

function check_grub_for_elevator {

 v_os_rel_num=$(cat /etc/redhat-release | awk '{print $7}' | awk -F. '{print $1}')

 if [ $v_os_rel_num -lt 7 ]
   then
     v_grub_file=/boot/grub/grub.conf
 else
     v_grub_file=/boot/grub2/grub.cfg
 fi

 if [ -r $v_grub_file ]
  then
    v_grub_deadline_check=$(cat $v_grub_file | grep -i vmlinuz-`uname -am | awk '{print $3}'` | grep -v vmlinuz-`uname -am | awk '{print $3}'`.debug | grep -i "elevator=deadline" | wc -l)
    if [ $v_grub_deadline_check = 1 ]
     then
       report_command=$(echo "$report_command\nelevator=deadline is found in grub config file.")
       status=0
    else
       report_command=$(echo "$report_command\nelevator=deadline is not found in grub config file.")
       status=1
    fi
 else
   report_command=$(echo "$report_command\nUnable to read grub config file.")
   status=1
 fi

}

function check_asm_disks_for_elevator {

if [ ${ORACLE_SID}x = x ]
 then
  report_command=$(echo "$report_command\nORACLE_SID not found.")
  status=1
elif [ `ps -ef| grep -w ora_smon_${ORACLE_SID} | grep -v grep | wc -l` -eq 1 ] || [ `ps -ef| grep -w asm_smon_${ORACLE_SID} | grep -v grep | wc -l` -eq 1 ]
 then
 v_asm_library=$(echo -e "set heading off feedback off timing off lines 180\n select distinct substr(library,1,11) from v\$asm_disk ;"|$ORACLE_HOME/bin/sqlplus -s / as sysdba|grep -v ^$)

 case $v_asm_library in
 System)
    asm_disks=$(echo -e "set heading off feedback off timing off lines 180\n select path from v\$asm_disk ;"|$ORACLE_HOME/bin/sqlplus -s / as sysdba|grep -v ^$)
    ;;
 "ASM Library")
    asm_list_disks=$(/usr/sbin/oracleasm listdisks)
    asm_disks=$(/usr/sbin/oracleasm querydisk -p $asm_list_disks | grep LABEL | awk -F':' '{print $1}' | sed -e 's/^ *//' -e 's/ *$//')
    report_command=$(echo "$report_command\n\nASM Lib to OS disk mapping is provided below:")
    report_command=$(echo "$report_command\n---------------------------------------------")
    report_command1=$(/usr/sbin/oracleasm querydisk -p `/usr/sbin/oracleasm listdisks` | grep LABEL | awk '{print $1 $2}')
    report_command=$(echo "${report_command}\n${report_command1}\n")
    ;;
 "AFD Library")
    asm_disks=$($ORACLE_HOME/bin/asmcmd afd_lsdsk | grep -v - | grep -v = | grep -v Label | awk '{print $3}' | sed -e 's/^ *//' -e 's/ *$//')
    report_command=$(echo "$report_command\n\nAFD Library to OS disk mapping is provided below:")
    report_command1=$($ORACLE_HOME/bin/asmcmd afd_lsdsk)
    report_command=$(echo "${report_command}\n${report_command1}\n")
    ;;
 CELL)
    ;;
 *)
    asm_disks=$(echo -e "set heading off feedback off timing off lines 180\n select path from v\$asm_disk ;"|$ORACLE_HOME/bin/sqlplus -s / as sysdba|grep -v ^$)
 ;;
 esac

 for asm_disk in `echo "$asm_disks"|grep '/dev/'`
 do
  # logic to handle OL7 based SYMLINKs
  if [ -L $asm_disk ]
    then
      v_lfile=$asm_disk
      lfile=$(ls -l "$asm_disk" 2>/dev/null|awk -F'->' '{print $2}' | sed -e 's/^ *//' -e 's/ *$//');
      asm_disk=$(basename "$lfile");
      v_os_dev=/dev/$asm_disk

  # logic to handle block devices
  elif [ -b $asm_disk ]
    then
      v_lfile=$(ls -l "$asm_disk" 2>/dev/null|awk '{print $10}' | sed -e 's/^ *//' -e 's/ *$//');
      v_asm_disk=$(basename "$v_lfile");

      # logic to handle dm-multipath devices
      if [ -L /dev/mpath/$v_asm_disk ]
        then
          lfile=$(ls -l "/dev/mpath/$v_asm_disk" 2>/dev/null|awk -F'->' '{print $2}' |awk -F'/' '{print $2}' | sed -e 's/^ *//' -e 's/ *$//');
          asm_disk=$(basename "$lfile");
          v_os_dev=/dev/mpath/$asm_disk
      else
      # logic to handle devices
          lfile=$(ls -l "$asm_disk" 2>/dev/null|awk '{print $10}' | sed -e 's/^ *//' -e 's/ *$//');
          asm_disk=$(basename "$lfile");
          v_os_dev=/dev/$asm_disk
      fi
  else
     report_command=$(echo "$report_command\nDevice type unknown")
    status=1
    break
  fi

   # check for deadline io scheduler
  if [ -e /sys/block/${asm_disk}/queue/scheduler ]
    then
      scheduler_count=$(cat /sys/block/${asm_disk}/queue/scheduler |grep -w "\[deadline\]" | wc -l )
      scheduler_info=$(cat /sys/block/${asm_disk}/queue/scheduler | sed 's/.*\[\([^]]*\)\].*/\1/')
      report_command=$(echo "$report_command\nASM Disk is: ${v_lfile}. Underlying OS Disk ${v_os_dev} is currently set to $scheduler_info")
      status=0
  elif [ -e /sys/block/*/${asm_disk}/../queue/scheduler ]
    then
      scheduler_count=$(cat /sys/block/*/${asm_disk}/../queue/scheduler |grep -w "\[deadline\]" | wc -l )
      scheduler_info=$(cat /sys/block/*/${asm_disk}/../queue/scheduler | sed 's/.*\[\([^]]*\)\].*/\1/')
      report_command=$(echo "$report_command\nASM Disk is ${v_lfile}. Underlying OS Disk ${v_os_dev} is currently set to $scheduler_info")
      status=0
  else
      report_command=$(echo "$report_command\nCould not obtain the IO Scheduler info for this device")
      status=1
      break
  fi

  if [[ $scheduler_count -lt 1 ]]
   then
    status=1
    break
  fi
 done
else
 report_command=$(echo "$report_command\nUnable to retrieve ASM Devices.")
 status=1 
fi
}

# initialize

status=0
report_command="IO Scheduler Report Output"
report_command=$(echo "$report_command\n---------------------------")

# main section

check_asm_disks_for_elevator

if [ $status = 1 ]
 then
   check_grub_for_elevator
fi

if [ $status = 1 ]
 then
   check_kernel_for_elevator
fi

# return the result
echo -e "$report_command"
exit $status


