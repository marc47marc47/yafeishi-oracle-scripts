#!/usr/local/bin/perl
# 
# $Header: tfa/src/orachk/src/readreg.pl gadiga_orachk_cygwin_support/3 2014/06/25 04:29:55 gadiga Exp $
#
# readreg.pl
# 
# Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      readreg.pl - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    gadiga      06/22/14 - read windows registry
#    gadiga      06/22/14 - Creation
# 

my $outdir = ".";
if ( $ARGV[0] && -d "$ARGV[0]" )
{
  $outdir = $ARGV[0];
}

open(F1, ">$outdir/registry.out");
open(F2, ">$outdir/windiscover.out");
open(F3, ">$outdir/win_oratab.out");

sub read_key
{
  my $key = shift;
  $key =~ s/\s+$//;
  #print "reg query \"$key\"\n";
  @out = `reg query "$key"`;
  chomp(@out);
  return @out;
}

sub get_dname
{
  my $h = shift;
  $h =~ s/\\/\//g;
  $h =~ s/^\s+//;
  $h =~ s/\s+$//;

  return $h;
}

# Main starts

system("sc query > $outdir/win_services.out");

my @out = read_key ("HKEY_LOCAL_MACHINE\\SOFTWARE\\Oracle");
my $line = "";


foreach $line(@out)
{
  print F1 "$line\n";
  if ( $line =~ /^\s+inst_loc\s+\w+\s+(.*)/ )
  { # Inventory location
    my $h = get_dname($1);
    print F2 "INV_LOC=$h\n";
  }

  #$line =~ s/\\/\\\\/g;
  if ( $line =~ /\\KEY_/ )
  { # Found a home
    $typ = "U";
    if ( $line =~ /KEY_ORAGI/i || $line =~ /KEY_ORACRS/i )
    { #GI/CRS Home
      $typ = "G";
    }
     elsif ( $line =~ /KEY_ORADB/i )
    {# Database home
      $typ = "R";
    }

    #print "Reading $line - $typ\n";
    @out1 = read_key($line);
    foreach my $line1 (@out1)
    {
      if ( $line1 =~ /^\s+ORACLE_HOME\s+\w+\s+(.*)/ )
      {
        my $h = get_dname($1);
        if ( $typ eq "R" )
        {
          my $v = `$h/bin/sqlplus -v`;
          #|awk '{print \$3}'|sed 's/\.//g'|sed '/^\$/d'`;
          chomp($v);
          $v =~ s/.*Release\s+//;
          $v =~ s/\s+.*//;
          my $s = "";
          my @files = `ls -1 $h/database $h/dbs| grep -i '.ora'`;
          chomp(@files);
          foreach my $file (@files)
          {
            if ( $file =~ /spfile(.*)\.ora/i || $file =~ /init(.*)\.ora/i )
            {
              $s = $1;
              if ( $s )
              {
                print F3 "$s|$h|N\n";
              }
            }
          }
          print F2 "ORACLE_HOME=$h|$s|$v\n";
        }
         elsif ( $typ eq "G" )
        {
          print F2 "CRS_INSTALLED=1\n";
          print F2 "CRS_HOME=$h\n";
        }
      }
      print F1 "$line1\n";
    }
  }
}

close(F1);
close(F2);
close(F3);

