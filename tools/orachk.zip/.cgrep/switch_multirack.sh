#multi_rack switch data collection

switch_file_path=$OUTPUTDIR
switch_file_name=$(ls $switch_file_path | grep -i "ibnetdiscover_exalogic" | head -1)
switch_list=$(cat $switch_file_path/$switch_file_name | grep -iv "REVIEW" | sort -r)

for line in $switch_list
do
report+="Information gathered on $line:\n\n"
switch=$(echo -e "$line" | awk -F"|" '{print $1}')
report+="\n\n  #getmaster on $switch:\n\n"
report+=$(ssh root@$switch getmaster)
report+="\n\n  #setsmpriority list on $switch:\n\n"
report+=$(ssh root@$switch setsmpriority list)
report+="\n\n  #smnodes list on $switch:\n\n"
report+=$(ssh root@$switch smnodes list)"\n\n"

done  

echo -e "$report"

